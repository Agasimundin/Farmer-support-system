document.addEventListener("DOMContentLoaded", function(){
    const wrapper= document.querySelector(".wrapper");
    const loginLink= document.querySelector(".login-link");
    const registerLink= document.querySelector(".register-link");
    const btnPopup= document.querySelector(".btn");
    const iconClose= document.querySelector(".icon-close");
    
    registerLink.addEventListener("click", ()=> {
        wrapper.classList.add("active");
    });
    
    loginLink.addEventListener("click", ()=>{
        wrapper.classList.remove("active");
    });
    
    btnPopup.addEventListener("click", ()=> {
        wrapper.classList.add("active-popup");
    });
    
    iconClose.addEventListener("click", ()=> {
        wrapper.classList.remove("active-popup");
    });
    });
    
    const loginForm = document.getElementById('loginForm');
    const email = document.getElementById('email');
    const password = document.getElementById('password');
    
    // Add an event listener to the form
    loginForm.addEventListener('submit', function(event) {
      // Prevent the form from submitting normally
      event.preventDefault();
    
      // Check if the entered email and password are correct
      if (email.value === 'nikhilup@gmail.com' && password.value === 'nikhil') {
        // If they are, perform the desired action (like navigating to a new page)
        window.location.href = 'nextpage.html';
      } else {
        // If they're not, display an error message
        alert('Wrong email or password');
      }
    });