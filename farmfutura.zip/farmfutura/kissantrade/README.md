# Microsoft Azure FRT Project
# link https://polite-pond-06aa7ef10.1.azurestaticapps.net

# Patchwork

<img width="958" alt="Screenshot 2022-07-22 194930" src="https://user-images.githubusercontent.com/90184024/180460929-729e5ae2-447e-4068-afae-1bc2dd65b29c.png">

<img width="960" alt="Screenshot 2022-07-22 195037" src="https://user-images.githubusercontent.com/90184024/180461547-a8a0080c-ab28-4b0d-a2f1-f52c32780030.png">

<img width="960" alt="Screenshot 2022-07-22 195118" src="https://user-images.githubusercontent.com/90184024/180461610-7d2a52b0-cd69-438f-9c4d-a944efd5a21b.png">

![Screenshot (204)](https://user-images.githubusercontent.com/90184024/180461693-048d00fd-e594-4c6b-999a-b42b04831a3d.png)

<img width="960" alt="Screenshot 2022-07-22 200040" src="https://user-images.githubusercontent.com/90184024/180461719-46cd82cf-33d7-4984-a400-995a419e082a.png">
